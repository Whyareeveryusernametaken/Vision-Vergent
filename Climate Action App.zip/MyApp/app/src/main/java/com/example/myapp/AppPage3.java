package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

public class AppPage3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_page3);

        ImageView myImageView = (ImageView) findViewById(R.id.Image_2);
        //ImageView.setImageResource(R.drawable.image2);
    }
}