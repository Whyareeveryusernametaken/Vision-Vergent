package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button HomepageBtn = (Button)findViewById(R.id.HomepageBtn);
        HomepageBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent  startIntent = new Intent(getApplicationContext(), AppPage2.class);

                startActivity(startIntent);

            }
        });
        Button HowWeImpactCO2EmissionsBtn = (Button)findViewById(R.id.Page_2_Btn);
        HowWeImpactCO2EmissionsBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent  startIntent = new Intent(getApplicationContext(), AppPage3.class);

                startActivity(startIntent);

            }
        });


        Button SolutionsBtn = (Button)findViewById(R.id.Page_4_Btn);
        SolutionsBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent  startIntent = new Intent(getApplicationContext(), AppPage5.class);

                startActivity(startIntent);

            }
        });
    }
}